export const applicationconfig = {
  title1: 'Smart',
  title2: 'Learn',
  // applicationName: 'Ariba'
};
