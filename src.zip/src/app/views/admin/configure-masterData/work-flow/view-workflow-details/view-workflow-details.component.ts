import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-workflow-details',
  templateUrl: './view-workflow-details.component.html',
  styleUrls: ['./view-workflow-details.component.scss']
})
export class ViewWorkflowDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
